package susan;

import lejos.hardware.*;

public class Main {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Hello, my name is Susan!"); // sysouts will appear at the display
		Button.waitForAnyPress(); // will wait for button press to end program: time to check whether code worked
		// for now: functions as a way to test whether the code was executed correctly
		
		Sound.setVolume(5);
		
		//Challenge3.launch();
		Challenge4.launch();
	}
}
