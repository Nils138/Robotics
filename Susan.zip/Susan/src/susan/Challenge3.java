package susan;

import java.util.concurrent.TimeUnit;

import lejos.hardware.Button;
import lejos.hardware.Sound;
import lejos.hardware.lcd.LCD;
import lejos.utility.Delay;

public class Challenge3 {

	public static void launch() throws InterruptedException {
		new WheelActuator();
		new ColorSensor();
		new UltrasonicSensor();
		Delay.msDelay(3000);
		
		int found = 0; // nr of found pillars
		
		while (found < 6) {
			WheelActuator.stop();
			Sound.beepSequenceUp();
			System.out.println("Starting search");
			float shortest = Float.POSITIVE_INFINITY;
			long r = System.currentTimeMillis();
			while (System.currentTimeMillis() - r < 8000) { // turn for 8 seconds, which is approximately a whole circle
				WheelActuator.turnLeft(1);
				if (UltrasonicSensor.getDistance() < shortest)
					shortest = UltrasonicSensor.getDistance();
			}
			if (shortest == Float.POSITIVE_INFINITY || shortest == 0.0) {
				System.out.println("Can't find anything");
				Sound.beepSequence();
				long s = System.currentTimeMillis();
				while (System.currentTimeMillis() - s < 5000) {
					WheelActuator.forward(100);
					if (ColorSensor.getRed()[0] > 0.55) { // white line
						WheelActuator.stop();
						Sound.beep();
						System.out.println("Can't go further!");
						WheelActuator.backward(100);
						Delay.msDelay(1000);
						WheelActuator.stop();
						WheelActuator.turnLeft(150);
						Delay.msDelay(1000);
						WheelActuator.stop();
						s = System.currentTimeMillis();
					}
				}
				continue;
			}

			WheelActuator.stop();
			Sound.beepSequenceUp();
			System.out.println("Looking for pillar");
			System.out.println(shortest);

			while (UltrasonicSensor.getDistance() < shortest - 0.08
					|| UltrasonicSensor.getDistance() > shortest + 0.08) {
				WheelActuator.turnLeft(1);
			}

			WheelActuator.stop();
			System.out.println("Found pillar!");
			WheelActuator.turnLeft(5);
			Sound.beepSequence();

			// Q: what is the relation between ambient light and actual ColorSensor/light
			// values?

			float[] rgb = ColorSensor.getRGB();
			while (rgb[0] < 0.05 && rgb[2] < 0.02) { // was 0.5 and 0.2 at some point
				// 0.05 and 0.02 are with ambient values 0.00-0.02
				rgb = ColorSensor.getRGB();
				WheelActuator.forward(150);
				if (ColorSensor.getRed()[0] > 0.25) { // white line, shouldn't be necessary here
					// value 0.3 is with ambient value 0.00 - 0.02
					// value 0.25 is also with ambient value 0.00-0.02 but with shadow on white line
					WheelActuator.stop();
					Sound.beep();
					System.out.println("Can't go further!");
					WheelActuator.backward(50);
					Delay.msDelay(1000);
					WheelActuator.stop();
					WheelActuator.turnLeft(150);
				}
			}

			WheelActuator.stop();

			// check for enemy/friend
			// pre: you're on top of a pillar

			if (rgb[0] > rgb[2] && rgb[0] > 0.05) { // pokemon battle/opening theme
				printCross();
				playEnemy();
				WheelActuator.forward(150);
				Delay.msDelay(500);
				WheelActuator.stop();
				found++;
				TimeUnit.SECONDS.sleep(5); // 5 seconds to remove found pillar
			} else {// Careless Whisper
				printHeart();
				playFriend();
				found++;
				Delay.msDelay(1000);
			}
		}
		playVictory();
		System.out.println("I'm done now");
		Button.waitForAnyPress();
	}

	public static void printHeart() {
		LCD.clear();
		System.out.println("     _    _");
		System.out.println("    / \\  / \\");
		System.out.println("   |   \\/   |");
		System.out.println("   |        |");
		System.out.println("    \\      /");
		System.out.println("     \\    /");
		System.out.println("      \\  / ");
		System.out.print("       \\/");
	}

	public static void printCross() {
		LCD.clear();
		System.out.println("       \\    /"); // extra spaces because it doesn't work without them
		System.out.println("	\\  /");
		System.out.println("	 \\/");
		System.out.println("	 /\\");
		System.out.println("	/  \\");
		System.out.println("       /    \\");
	}

	public static void playFriend() {
		int[] frequencies = { 880, 932, 1046, 1174, 1318, 1174, 880, 698, 1318, 1174, 880, 698, 1046, 932, 698, 587,
				1046, 932, 698, 932, 880, 698, 587, 466, 440, 466, 523, 587, 659, 698, 784, 880 };
		int[] durations = { 98, 98, 98, 98, 392, 196, 392, 392, 588, 196, 392, 588, 392, 196, 392, 392, 588, 196, 980,
				392, 196, 392, 392, 1764, 392, 392, 392, 392, 392, 392, 392, 392 };
		for (int i = 0; i < frequencies.length; i++) {
			Sound.playTone(frequencies[i], durations[i]);
		}
		// Source: George Michael (Wham) - Careless Whisper
	}

	public static void playEnemy() {
		int[] frequencies = { 1760, 1567, 1396, 1318, 1760, 1318, 1396, 1318, 1760, 1244, 1318, 1244, 1760, 1174, 1318,
				1174, 1760, 1108, 1174, 1108, 1760, 987, 1046, 987, 1760, 932, 987, 932, 1760 };
		for (int i = 0; i < frequencies.length; i++) {
			Sound.playTone(frequencies[i], 88);
		}

		// Source: Pokemon Red/Blue Battle Theme
	}

	public static void playVictory() {
		int[] frequencies = { 392, 523, 659, 784, 1046, 1318, 1568, 1318, 415, 523, 622, 830, 1046, 1245, 1661, 1397,
				466, 587, 698, 932, 1175, 1396, 1865, 1865, 1865, 1865, 2093 };
		int[] durations = { 133, 133, 133, 133, 133, 133, 399, 399, 133, 133, 133, 133, 133, 133, 399, 399, 133, 133,
				133, 133, 133, 133, 399, 100, 100, 100, 798 };
		for (int i = 0; i < frequencies.length; i++) {
			if (i >= 23 && i <= 25)
				Delay.msDelay(33);
			Sound.playTone(frequencies[i], durations[i]);
		}
		// Source: Flagpole Fanfare - Super Mario Bros
	}

}