package susan;

import lejos.hardware.sensor.EV3TouchSensor;
import lejos.hardware.port.SensorPort;

public class TouchSensor {
	EV3TouchSensor touch;
	float[] sample;
	
	public TouchSensor() {
		touch = new EV3TouchSensor(SensorPort.S4);
		sample = new float[touch.sampleSize()];
	}
	
	public boolean isTouched() {
		touch.fetchSample(sample, 0);
		if (sample[0] == 1)
			return true;
		return false;
	}
}

