package susan;

import lejos.hardware.Sound;
import lejos.utility.Delay;

public class Challenge4 {

	public static void launch() {
		// when you only see black: turn a little left and right, and if you still don't
		// find the line, you're at the food
		
		WheelActuator.forward(150);
		Delay.msDelay(4000);
		WheelActuator.stop();
		Sound.beepSequenceUp();
		float[] rgb = ColorSensor.getRGB();
		long t = System.currentTimeMillis();
		while (UltrasonicSensor.getDistance() > 1 || System.currentTimeMillis() - t < 20000) { // 20 seconds -> meten
			LineFollower.go();
		}
		Sound.beepSequence();
		while (rgb[0] < 0.05 && rgb[2] < 0.02) {
			WheelActuator.forward(100);
			rgb = ColorSensor.getRGB();
		}
		Sound.beep();
		while (ColorSensor.getRed()[0] < 0.25) { // go back to the line
			WheelActuator.backward(50);
		}
		Sound.beepSequence();
		WheelActuator.stop();
		if (rgb[0] < rgb[2])
			LineFollowerRightPath();
		if (rgb[0] > rgb[2])
			LineFollowerLeftPath();
		// pre: you're in front of a block
		grabBlock();
		WheelActuator.turnLeft(200);
		WheelActuator.forward(100);
		Delay.msDelay(2500);
		WheelActuator.stop();
		long u = System.currentTimeMillis();
		while (System.currentTimeMillis() - u < 25000)
			LineFollower.go();
		dropBlock();
		WheelActuator.backward(50);
	}

	public static void dropBlock() {
		ArmActuator.open();
		WheelActuator.backward(100);
		Delay.msDelay(2000);
		WheelActuator.stop();
		ArmActuator.close();
	}

	public static void grabBlock() {
		ArmActuator.open();
		WheelActuator.forward(50);
		Delay.msDelay(2500);
		WheelActuator.stop();
		ArmActuator.close();
	}

	public static void LineFollowerLeftPath() {
		WheelActuator.turnLeft(10);
		LineFollower.go();
		long t = System.currentTimeMillis();
		if (System.currentTimeMillis() - t >= 7000)
			LineFollower.stop();
	}

	public static void LineFollowerRightPath() {
		WheelActuator.turnRight(10);
		LineFollower.go();
		long t = System.currentTimeMillis();
		if (System.currentTimeMillis() - t >= 7000)
			LineFollower.stop();
	}
}
