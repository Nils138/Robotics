package susan;

import lejos.hardware.port.SensorPort;
import lejos.hardware.sensor.EV3UltrasonicSensor;
import lejos.robotics.SampleProvider;

public class UltrasonicSensor {
	private static final EV3UltrasonicSensor sensor = new EV3UltrasonicSensor(SensorPort.S4);
	private static final SampleProvider sample = sensor.getDistanceMode();
	private static final float[] distance = new float[sample.sampleSize()];
	
	public static float getDistance() {
		sample.fetchSample(distance, 0);
		return distance[0]; //range is at least from 0.05 to 1.67
	}
}
