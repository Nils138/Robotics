package susan;

import lejos.hardware.port.SensorPort;
import lejos.hardware.sensor.EV3ColorSensor;
import lejos.robotics.SampleProvider;

public class ColorSensor {
	private static final EV3ColorSensor port = new EV3ColorSensor(SensorPort.S1);
	private static final SampleProvider rgb = port.getRGBMode();
	private static final float[] rgbSample = new float[rgb.sampleSize()];
	private static final SampleProvider red = port.getRedMode();
	private static final float[] redSample = new float[red.sampleSize()];

	public static float[] getRGB() {
		rgb.fetchSample(rgbSample, 0);
		return rgbSample;
	}

	public static float[] getRed() {
		red.fetchSample(redSample, 0);
		return redSample;
	}
}
