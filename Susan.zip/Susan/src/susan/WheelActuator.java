package susan;

import lejos.hardware.port.MotorPort;
import lejos.hardware.motor.EV3MediumRegulatedMotor;

public class WheelActuator {
	static final EV3MediumRegulatedMotor left = new EV3MediumRegulatedMotor(MotorPort.A);
	static final EV3MediumRegulatedMotor right = new EV3MediumRegulatedMotor(MotorPort.D);
	
	public static void setSpeed(int speed) {
		left.setSpeed(speed);
		right.setSpeed(speed);
	}
	
	public static void backward(int speed) { //backward and forward is reversed because we have our wheels at the back
		left.setSpeed(speed);
		left.forward();
		right.setSpeed(speed);
		right.forward();
	}

	public static void forward(int speed) {
		left.setSpeed(speed);
		left.backward();
		right.setSpeed(speed);
		right.backward();
	}
	
	public static void turnTo(int angle) {
		left.rotateTo(-2 * angle);
		right.rotateTo(2 * angle);
	}

	public static void turnRight(int angle) {
		left.rotate(2 * angle); //rotate or rotateto doesn't make a difference
		right.rotate(-2 * angle);
	}

	public static void turnLeft(int angle) {
		right.rotate(2 * angle); //rotate means rotate the single wheel
		left.rotate(-2 * angle);
	}

	public static void stop() {
		right.stop(true);
		left.stop(true);
	}

}
