package susan;

import lejos.hardware.port.SensorPort;
import lejos.hardware.sensor.EV3ColorSensor;
import lejos.robotics.SampleProvider;

public class AmbientSensor {
	EV3ColorSensor port;
	SampleProvider ambient;
	float[] sample;

	public AmbientSensor() {
		port = new EV3ColorSensor(SensorPort.S1);
		ambient = port.getAmbientMode();
		sample = new float[ambient.sampleSize()];
	}

	public float[] getAmbient() {
		ambient.fetchSample(sample, 0);
		return sample;
	}
}

