package susan;

public class LineFollower {
	// on the right side of the line
	// select Reflected light intensity on SUSAN:
	// tools --> test sensors
	// measure reflected light intensity when on 50% black and 50% white, that's
	// your target

	// values to set
	private static double target = 26;
	private static double Kp = 0.5;
	private static double Ki = 0.6;
	private static double Kd = 1;
	private static double turn = 0;
	private static double turnLeft = 7;
	private static double turnRight = 36;
	private static int extraSpeed = 210;
	private static int speedSharp = 130;
	private static int forwardSpeed = 210;

	// values to just initialize to 0
	private static double proportional = 0;
	private static double integral = 0;
	private static double derivative = 0;
	private static double error = 0;
	private static double lastError = 0;
	private static double value = 0;

	public static void setTarget(double tempTarget) {
		target = tempTarget;
	}

	public static void setTurnLeft(double tempTurnLeft) {
		turnLeft = tempTurnLeft;
	}

	public static void setTurnRight(double tempTurnRight) {
		turnRight = tempTurnRight;
	}

	public static void go() {
		value = ColorSensor.getRed()[0] * 100; // measure reflected light intensity

		if (value < turnLeft) // robot on only black: sharp left turn
		{
			WheelActuator.setSpeed(speedSharp);
			WheelActuator.right.forward();
			WheelActuator.left.backward();
		} else if (value > turnRight) // robot on only white: sharp right turn
		{
			WheelActuator.setSpeed(speedSharp);
			WheelActuator.right.backward();
			WheelActuator.left.forward();
		} else {
			WheelActuator.forward(forwardSpeed);
		}

		// calculations
		error = target - value;
		proportional = (error) * Kp;
		integral = (integral + error) * Ki;
		derivative = (error - lastError) * Kd;

		turn = proportional + integral + derivative; // 'the steering value' forward the motors

		if (turn > 0) // value < target --> we are too much on black
		{
			WheelActuator.right.setSpeed((int) turn + extraSpeed);
			WheelActuator.right.forward();
		} else // target < value --> we are too much on white
		{
			WheelActuator.left.setSpeed((int) turn * -1 + extraSpeed);
			WheelActuator.left.forward();
		}

		lastError = error;
	}

	public static void stop() {
		WheelActuator.setSpeed(0);
	}
}
