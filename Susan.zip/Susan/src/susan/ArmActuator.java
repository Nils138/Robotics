package susan;

import lejos.hardware.port.MotorPort;
import lejos.utility.Delay;
import lejos.hardware.motor.EV3MediumRegulatedMotor;

public class ArmActuator {
	private static final EV3MediumRegulatedMotor arm = new EV3MediumRegulatedMotor(MotorPort.B);

	public static void open() {
		arm.forward();
		Delay.msDelay(500);
		arm.stop();
	}
	
	public static void close() { //maybe close tighter than opening?
		arm.backward();
		Delay.msDelay(500);
		arm.stop();
	}
}
