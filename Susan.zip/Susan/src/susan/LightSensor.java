package susan;

public class LightSensor {

}
